export interface User {
  id: string;
  name: string;
  email: string;
  height?: number; // in cm
  weight?: number; // in kg
  goalWeight?: number; // in kg
  dateOfBirth?: string;
  joinedDate: string;
}

export interface Exercise {
  id: string;
  name: string;
  category: 'strength' | 'cardio' | 'flexibility' | 'balance' | 'other';
  muscleGroups: string[];
  defaultSets?: number;
  defaultReps?: number;
  defaultDuration?: number; // in seconds
  defaultDistance?: number; // in meters
  defaultWeight?: number; // in kg
}

export interface WorkoutSet {
  id: string;
  exerciseId: string;
  reps?: number;
  weight?: number; // in kg
  duration?: number; // in seconds
  distance?: number; // in meters
  completed: boolean;
}

export interface Workout {
  id: string;
  userId: string;
  name: string;
  date: string;
  duration: number; // in seconds
  caloriesBurned?: number;
  notes?: string;
  sets: WorkoutSet[];
  completed: boolean;
}

export interface Goal {
  id: string;
  userId: string;
  title: string;
  description?: string;
  targetDate: string;
  category: 'weight' | 'workout' | 'nutrition' | 'other';
  targetValue: number;
  currentValue: number;
  unit: string;
  completed: boolean;
}

export interface NutritionEntry {
  id: string;
  userId: string;
  date: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  foodName: string;
  calories: number;
  protein: number; // in grams
  carbs: number; // in grams
  fat: number; // in grams
}

export interface WeightEntry {
  id: string;
  userId: string;
  date: string;
  weight: number; // in kg
}

export interface DashboardStats {
  workoutsThisWeek: number;
  totalWorkouts: number;
  activeGoals: number;
  completedGoals: number;
  currentStreak: number;
  caloriesBurnedThisWeek: number;
}