import React from 'react';
import { Card, CardTitle, CardContent } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { NutritionEntry } from '../../types';

interface NutritionCardProps {
  entry: NutritionEntry;
  onClick?: () => void;
}

const NutritionCard: React.FC<NutritionCardProps> = ({ entry, onClick }) => {
  const getMealTypeBadge = () => {
    switch (entry.mealType) {
      case 'breakfast':
        return <Badge variant="primary" rounded>Breakfast</Badge>;
      case 'lunch':
        return <Badge variant="success" rounded>Lunch</Badge>;
      case 'dinner':
        return <Badge variant="info" rounded>Dinner</Badge>;
      case 'snack':
        return <Badge variant="warning" rounded>Snack</Badge>;
      default:
        return null;
    }
  };

  return (
    <Card 
      className="transition-all duration-200 hover:shadow-md cursor-pointer"
      onClick={onClick}
    >
      <CardContent>
        <div className="flex justify-between items-start mb-3">
          <CardTitle>{entry.foodName}</CardTitle>
          {getMealTypeBadge()}
        </div>
        
        <div className="text-lg font-semibold text-blue-600 mb-3">
          {entry.calories} calories
        </div>
        
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-blue-50 p-2 rounded-md">
            <div className="text-xs text-gray-600">Protein</div>
            <div className="font-semibold text-blue-700">{entry.protein}g</div>
          </div>
          <div className="bg-green-50 p-2 rounded-md">
            <div className="text-xs text-gray-600">Carbs</div>
            <div className="font-semibold text-green-700">{entry.carbs}g</div>
          </div>
          <div className="bg-yellow-50 p-2 rounded-md">
            <div className="text-xs text-gray-600">Fat</div>
            <div className="font-semibold text-yellow-700">{entry.fat}g</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default NutritionCard;