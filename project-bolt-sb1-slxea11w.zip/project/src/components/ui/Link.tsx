import React from 'react';

interface LinkProps {
  href: string;
  children: React.ReactNode;
  className?: string;
  activeClassName?: string;
  onClick?: () => void;
}

export const Link: React.FC<LinkProps> = ({ 
  href, 
  children, 
  className = '', 
  activeClassName = '',
  onClick
}) => {
  // This is a simple implementation - in a real app you'd use a router
  const isActive = window.location.pathname === href;
  const combinedClassName = isActive && activeClassName 
    ? `${className} ${activeClassName}` 
    : className;

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // Update URL without full page reload
    window.history.pushState({}, '', href);
    // Dispatch an event so other components can react to the URL change
    window.dispatchEvent(new Event('popstate'));
    
    if (onClick) {
      onClick();
    }
  };

  return (
    <a 
      href={href} 
      className={combinedClassName}
      onClick={handleClick}
    >
      {children}
    </a>
  );
};