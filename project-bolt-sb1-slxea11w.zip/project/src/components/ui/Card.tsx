import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ 
  children, 
  className = '',
  onClick
}) => {
  return (
    <div 
      className={`bg-white rounded-lg shadow-sm p-6 ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

export const CardTitle: React.FC<{children: React.ReactNode}> = ({ children }) => {
  return <h3 className="text-lg font-semibold text-gray-900 mb-2">{children}</h3>;
};

export const CardContent: React.FC<{children: React.ReactNode}> = ({ children }) => {
  return <div className="text-gray-600">{children}</div>;
};

export const CardFooter: React.FC<{children: React.ReactNode}> = ({ children }) => {
  return <div className="mt-4 pt-4 border-t border-gray-100">{children}</div>;
};