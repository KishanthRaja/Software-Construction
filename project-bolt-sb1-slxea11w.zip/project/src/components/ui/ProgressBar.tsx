import React from 'react';

interface ProgressBarProps {
  value: number;
  max: number;
  className?: string;
  showLabel?: boolean;
  labelFormat?: (value: number, max: number) => string;
  color?: 'blue' | 'green' | 'red' | 'yellow' | 'indigo';
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max,
  className = '',
  showLabel = false,
  labelFormat,
  color = 'blue',
  size = 'md',
  animated = false,
}) => {
  const percentage = Math.min(Math.max(0, (value / max) * 100), 100);
  
  const colorClasses = {
    blue: 'bg-blue-600',
    green: 'bg-green-500',
    red: 'bg-red-500',
    yellow: 'bg-yellow-500',
    indigo: 'bg-indigo-600',
  };
  
  const sizeClasses = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-4',
  };
  
  const animationClass = animated ? 'transition-all duration-500 ease-in-out' : '';
  
  const formatLabel = () => {
    if (labelFormat) {
      return labelFormat(value, max);
    }
    return `${Math.round(percentage)}%`;
  };

  return (
    <div className={`w-full ${className}`}>
      <div className="w-full bg-gray-200 rounded-full overflow-hidden">
        <div
          className={`${colorClasses[color]} ${sizeClasses[size]} ${animationClass} rounded-full`}
          style={{ width: `${percentage}%` }}
        />
      </div>
      {showLabel && (
        <div className="mt-1 text-xs text-gray-500 font-medium">
          {formatLabel()}
        </div>
      )}
    </div>
  );
};