import React from 'react';
import { Card, CardTitle, CardContent, CardFooter } from '../ui/Card';
import { ProgressBar } from '../ui/ProgressBar';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Calendar, Clock } from 'lucide-react';
import { Goal } from '../../types';
import { formatReadable, daysBetween } from '../../utils/dateUtils';

interface GoalCardProps {
  goal: Goal;
  onClick?: () => void;
}

const GoalCard: React.FC<GoalCardProps> = ({ goal, onClick }) => {
  const progress = (goal.currentValue / goal.targetValue) * 100;
  const daysLeft = goal.targetDate !== 'ongoing' 
    ? daysBetween(new Date().toISOString().split('T')[0], goal.targetDate) 
    : null;
  
  const getProgressColor = () => {
    if (goal.completed) return 'green';
    if (progress >= 75) return 'green';
    if (progress >= 50) return 'blue';
    if (progress >= 25) return 'yellow';
    return 'red';
  };
  
  const getCategoryBadge = () => {
    switch (goal.category) {
      case 'weight':
        return <Badge variant="primary" rounded>Weight</Badge>;
      case 'workout':
        return <Badge variant="success" rounded>Workout</Badge>;
      case 'nutrition':
        return <Badge variant="info" rounded>Nutrition</Badge>;
      default:
        return <Badge variant="default" rounded>Other</Badge>;
    }
  };

  return (
    <Card 
      className="h-full transition-all duration-200 hover:shadow-md cursor-pointer"
      onClick={onClick}
    >
      <CardContent>
        <div className="flex justify-between items-start mb-2">
          <CardTitle>{goal.title}</CardTitle>
          {getCategoryBadge()}
        </div>
        
        {goal.description && (
          <p className="text-gray-600 text-sm mb-4">{goal.description}</p>
        )}
        
        <div className="mb-4">
          <ProgressBar 
            value={goal.currentValue} 
            max={goal.targetValue} 
            showLabel
            labelFormat={(value, max) => 
              `${value} / ${max} ${goal.unit}`
            }
            color={getProgressColor()}
            animated
          />
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-2">
          <Calendar className="w-4 h-4 mr-2" />
          <span>
            {goal.targetDate === 'ongoing' 
              ? 'Ongoing goal'
              : `Target: ${formatReadable(goal.targetDate)}`
            }
          </span>
        </div>
        
        {daysLeft !== null && (
          <div className="flex items-center text-gray-500 text-sm">
            <Clock className="w-4 h-4 mr-2" />
            <span>
              {daysLeft > 0 
                ? `${daysLeft} day${daysLeft !== 1 ? 's' : ''} left`
                : 'Due today'
              }
            </span>
          </div>
        )}
      </CardContent>
      
      <CardFooter>
        <Button 
          variant={goal.completed ? 'success' : 'primary'} 
          size="sm" 
          fullWidth
          disabled={goal.completed}
        >
          {goal.completed ? 'Completed' : 'Update Progress'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default GoalCard;