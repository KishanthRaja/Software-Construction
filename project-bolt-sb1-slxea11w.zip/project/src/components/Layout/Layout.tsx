import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';
import PageContainer from './PageContainer';
import Dashboard from '../../pages/Dashboard';
import Workouts from '../../pages/Workouts';
import Goals from '../../pages/Goals';
import Nutrition from '../../pages/Nutrition';
import History from '../../pages/History';
import Profile from '../../pages/Profile';

const Layout: React.FC = () => {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handleLocationChange);
    
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
    };
  }, []);

  // Render the appropriate page based on the current path
  const renderPage = () => {
    switch (currentPath) {
      case '/':
        return <Dashboard />;
      case '/workouts':
        return <Workouts />;
      case '/goals':
        return <Goals />;
      case '/nutrition':
        return <Nutrition />;
      case '/history':
        return <History />;
      case '/profile':
        return <Profile />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <PageContainer>
        {renderPage()}
      </PageContainer>
    </div>
  );
};

export default Layout;