import React from 'react';
import { Card, CardTitle, CardContent, CardFooter } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Dumbbell, Clock, CalendarClock, ChevronRight } from 'lucide-react';
import { Workout } from '../../types';
import { formatReadable, formatDuration, isToday, isFuture } from '../../utils/dateUtils';

interface WorkoutCardProps {
  workout: Workout;
  onClick?: () => void;
}

const WorkoutCard: React.FC<WorkoutCardProps> = ({ workout, onClick }) => {
  const isUpcoming = isFuture(workout.date);
  const isScheduledToday = isToday(workout.date);
  
  const exerciseCount = new Set(workout.sets.map(set => set.exerciseId)).size;
  
  return (
    <Card 
      className="h-full transition-all duration-200 hover:shadow-md cursor-pointer"
      onClick={onClick}
    >
      <CardContent>
        <div className="flex justify-between items-start mb-3">
          <CardTitle>{workout.name}</CardTitle>
          {!workout.completed && (
            <Badge 
              variant={isScheduledToday ? 'warning' : isUpcoming ? 'info' : 'danger'} 
              size="sm"
            >
              {isScheduledToday ? 'Today' : isUpcoming ? 'Upcoming' : 'Missed'}
            </Badge>
          )}
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-2">
          <CalendarClock className="w-4 h-4 mr-2" />
          <span>{formatReadable(workout.date)}</span>
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-3">
          <Clock className="w-4 h-4 mr-2" />
          <span>{formatDuration(workout.duration)}</span>
        </div>
        
        <div className="flex items-center text-gray-500 text-sm">
          <Dumbbell className="w-4 h-4 mr-2" />
          <span>{exerciseCount} exercise{exerciseCount !== 1 ? 's' : ''}</span>
        </div>
        
        {workout.caloriesBurned && (
          <div className="mt-3 text-sm">
            <span className="font-medium text-blue-600">{workout.caloriesBurned}</span>
            <span className="text-gray-500"> calories burned</span>
          </div>
        )}
      </CardContent>
      
      <CardFooter>
        <Button 
          variant={workout.completed ? 'outline' : 'primary'} 
          size="sm" 
          fullWidth
          icon={<ChevronRight className="w-4 h-4" />}
          iconPosition="right"
        >
          {workout.completed ? 'View Details' : isUpcoming ? 'Start Workout' : 'Complete Workout'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default WorkoutCard;