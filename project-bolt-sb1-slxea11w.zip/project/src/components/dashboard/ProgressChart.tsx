import React from 'react';
import { Card, CardTitle } from '../ui/Card';

interface DataPoint {
  date: string;
  value: number;
}

interface ProgressChartProps {
  title: string;
  data: DataPoint[];
  color?: string;
  height?: number;
  yAxisLabel?: string;
  xAxisLabel?: string;
}

const ProgressChart: React.FC<ProgressChartProps> = ({
  title,
  data,
  color = '#3B82F6',
  height = 200,
  yAxisLabel,
  xAxisLabel,
}) => {
  // Find min and max values for scaling
  const values = data.map(d => d.value);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  const range = maxValue - minValue;
  
  // Padding for top and bottom of chart
  const padding = range * 0.1;
  const adjustedMin = Math.max(0, minValue - padding);
  const adjustedMax = maxValue + padding;
  
  // Create points for SVG polyline
  const chartWidth = 100; // Using percentages for responsive behavior
  const chartHeight = height - 40; // Allow space for axis labels
  
  const points = data.map((point, index) => {
    const x = (index / (data.length - 1)) * chartWidth;
    const normalizedValue = (point.value - adjustedMin) / (adjustedMax - adjustedMin);
    const y = chartHeight - (normalizedValue * chartHeight);
    return `${x},${y}`;
  }).join(' ');
  
  // Only show a subset of dates on the x-axis for readability
  const dateLabels = data.filter((_, i) => i % Math.ceil(data.length / 5) === 0 || i === data.length - 1);

  return (
    <Card>
      <CardTitle>{title}</CardTitle>
      <div className="mt-4" style={{ height: `${height}px` }}>
        <svg width="100%" height="100%" viewBox={`0 0 100 ${height}`} preserveAspectRatio="none">
          {/* Y-axis grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = chartHeight - (ratio * chartHeight);
            const value = adjustedMin + (ratio * (adjustedMax - adjustedMin));
            return (
              <g key={`grid-${ratio}`}>
                <line
                  x1="0"
                  y1={y}
                  x2="100"
                  y2={y}
                  stroke="#e5e7eb"
                  strokeWidth="0.5"
                />
                <text
                  x="-5"
                  y={y + 4}
                  fontSize="8"
                  textAnchor="end"
                  fill="#6b7280"
                >
                  {Math.round(value)}
                </text>
              </g>
            );
          })}
          
          {/* Chart line */}
          <polyline
            points={points}
            fill="none"
            stroke={color}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          
          {/* Data points */}
          {data.map((point, index) => {
            const x = (index / (data.length - 1)) * chartWidth;
            const normalizedValue = (point.value - adjustedMin) / (adjustedMax - adjustedMin);
            const y = chartHeight - (normalizedValue * chartHeight);
            
            return (
              <circle
                key={`point-${index}`}
                cx={x}
                cy={y}
                r="2"
                fill="white"
                stroke={color}
                strokeWidth="1.5"
              />
            );
          })}
          
          {/* X-axis labels */}
          {dateLabels.map((label, index) => {
            const x = (data.indexOf(label) / (data.length - 1)) * chartWidth;
            return (
              <text
                key={`label-${index}`}
                x={x}
                y={height - 5}
                fontSize="8"
                textAnchor="middle"
                fill="#6b7280"
              >
                {label.date.split('-').slice(1).join('/')}
              </text>
            );
          })}
          
          {/* Axis labels */}
          {yAxisLabel && (
            <text
              x="-30"
              y={chartHeight / 2}
              fontSize="9"
              textAnchor="middle"
              fill="#6b7280"
              transform={`rotate(-90, -30, ${chartHeight / 2})`}
            >
              {yAxisLabel}
            </text>
          )}
          
          {xAxisLabel && (
            <text
              x={chartWidth / 2}
              y={height - 10}
              fontSize="9"
              textAnchor="middle"
              fill="#6b7280"
            >
              {xAxisLabel}
            </text>
          )}
        </svg>
      </div>
    </Card>
  );
};

export default ProgressChart;