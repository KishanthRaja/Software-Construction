import React from 'react';
import { Card, CardTitle } from '../ui/Card';
import { formatReadable } from '../../utils/dateUtils';

interface Activity {
  id: string;
  date: string;
  type: 'workout' | 'goal' | 'weight';
  title: string;
}

interface ActivityCalendarProps {
  activities: Activity[];
  month?: Date;
}

const ActivityCalendar: React.FC<ActivityCalendarProps> = ({
  activities,
  month = new Date(),
}) => {
  // Get days in current month
  const firstDay = new Date(month.getFullYear(), month.getMonth(), 1);
  const lastDay = new Date(month.getFullYear(), month.getMonth() + 1, 0);
  const daysInMonth = lastDay.getDate();
  
  // Get day of week for first day (0 = Sunday, 1 = Monday, etc.)
  const firstDayOfWeek = firstDay.getDay();
  
  // Create array of day numbers with empty slots for days before first day of month
  const days = [...Array(firstDayOfWeek).fill(null), ...Array(daysInMonth).fill(0).map((_, i) => i + 1)];
  
  // Group activities by date
  const activityMap: { [key: string]: Activity[] } = {};
  activities.forEach(activity => {
    const date = activity.date.split('T')[0];
    if (!activityMap[date]) {
      activityMap[date] = [];
    }
    activityMap[date].push(activity);
  });
  
  // Get activity intensity for each day (0 = none, 1 = low, 2 = medium, 3 = high)
  const getIntensity = (day: number | null) => {
    if (day === null) return 0;
    
    const date = new Date(month.getFullYear(), month.getMonth(), day).toISOString().split('T')[0];
    const dayActivities = activityMap[date] || [];
    
    return Math.min(Math.ceil(dayActivities.length / 2), 3);
  };
  
  // Get color class based on intensity
  const getColorClass = (intensity: number) => {
    switch (intensity) {
      case 0: return 'bg-gray-100';
      case 1: return 'bg-blue-200';
      case 2: return 'bg-blue-400';
      case 3: return 'bg-blue-600';
      default: return 'bg-gray-100';
    }
  };
  
  const weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  
  // Function to render tooltips
  const renderTooltip = (day: number | null) => {
    if (day === null) return null;
    
    const date = new Date(month.getFullYear(), month.getMonth(), day).toISOString().split('T')[0];
    const dayActivities = activityMap[date] || [];
    
    if (dayActivities.length === 0) return null;
    
    return (
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-48 bg-white shadow-lg rounded-md p-2 text-xs z-10 hidden group-hover:block">
        <div className="font-semibold mb-1">{formatReadable(date)}</div>
        <ul>
          {dayActivities.map((activity, index) => (
            <li key={index} className="py-1 border-t border-gray-100 first:border-0">
              <span 
                className={`inline-block w-2 h-2 rounded-full mr-2 ${
                  activity.type === 'workout' ? 'bg-blue-500' : 
                  activity.type === 'goal' ? 'bg-green-500' : 'bg-purple-500'
                }`}
              />
              {activity.title}
            </li>
          ))}
        </ul>
      </div>
    );
  };

  return (
    <Card>
      <CardTitle>Activity Calendar</CardTitle>
      <div className="mt-4">
        <div className="grid grid-cols-7 gap-1 mb-2">
          {weekdays.map(day => (
            <div key={day} className="text-xs text-center font-medium text-gray-500">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {days.map((day, index) => {
            const intensity = getIntensity(day);
            const colorClass = getColorClass(intensity);
            const isToday = day === new Date().getDate() && 
                            month.getMonth() === new Date().getMonth() && 
                            month.getFullYear() === new Date().getFullYear();
            
            return (
              <div 
                key={index} 
                className={`
                  relative group aspect-square rounded-md flex items-center justify-center 
                  ${day === null ? 'invisible' : ''} 
                  ${isToday ? 'ring-2 ring-blue-500' : ''}
                `}
              >
                <div 
                  className={`
                    w-full h-full rounded-md flex items-center justify-center text-xs
                    ${colorClass} 
                    ${intensity > 1 ? 'text-white' : 'text-gray-800'}
                    transition-all duration-200 hover:scale-110
                  `}
                >
                  {day}
                </div>
                {renderTooltip(day)}
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
};

export default ActivityCalendar;