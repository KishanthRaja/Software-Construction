import React from 'react';
import { Card, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { User, Mail, Calendar, Ruler, Weight, Award, Settings, LogOut } from 'lucide-react';
import { currentUser, workouts, goals } from '../data/mockData';
import { formatReadable } from '../utils/dateUtils';

const Profile: React.FC = () => {
  // Calculate stats
  const totalWorkouts = workouts.filter(w => w.completed).length;
  const completedGoals = goals.filter(g => g.completed).length;
  const joinDate = formatReadable(currentUser.joinedDate);
  
  // Calculate age
  const calculateAge = (dateOfBirth: string): number => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };
  
  const age = currentUser.dateOfBirth ? calculateAge(currentUser.dateOfBirth) : null;
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
        
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            icon={<Settings className="w-4 h-4" />}
          >
            Settings
          </Button>
          <Button
            variant="outline"
            size="sm"
            icon={<LogOut className="w-4 h-4" />}
          >
            Sign Out
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div>
          <Card className="p-6">
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <User className="w-12 h-12 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold text-gray-900">{currentUser.name}</h2>
              <p className="text-gray-500">Member since {joinDate}</p>
              
              <div className="mt-6 grid grid-cols-3 gap-4 w-full">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{totalWorkouts}</div>
                  <div className="text-xs text-gray-500">Workouts</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{completedGoals}</div>
                  <div className="text-xs text-gray-500">Goals</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">4</div>
                  <div className="text-xs text-gray-500">Streak</div>
                </div>
              </div>
              
              <Button
                variant="primary"
                fullWidth
                className="mt-6"
              >
                Edit Profile
              </Button>
            </div>
          </Card>
          
          <Card className="p-6 mt-6">
            <CardTitle>Personal Information</CardTitle>
            
            <div className="mt-4 space-y-4">
              <div className="flex items-center">
                <Mail className="w-5 h-5 text-gray-400 mr-3" />
                <div>
                  <div className="text-sm text-gray-500">Email</div>
                  <div className="font-medium">{currentUser.email}</div>
                </div>
              </div>
              
              {age && (
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 text-gray-400 mr-3" />
                  <div>
                    <div className="text-sm text-gray-500">Age</div>
                    <div className="font-medium">{age} years</div>
                  </div>
                </div>
              )}
              
              {currentUser.height && (
                <div className="flex items-center">
                  <Ruler className="w-5 h-5 text-gray-400 mr-3" />
                  <div>
                    <div className="text-sm text-gray-500">Height</div>
                    <div className="font-medium">{currentUser.height} cm</div>
                  </div>
                </div>
              )}
              
              {currentUser.weight && (
                <div className="flex items-center">
                  <Weight className="w-5 h-5 text-gray-400 mr-3" />
                  <div>
                    <div className="text-sm text-gray-500">Current Weight</div>
                    <div className="font-medium">{currentUser.weight} kg</div>
                  </div>
                </div>
              )}
              
              {currentUser.goalWeight && (
                <div className="flex items-center">
                  <Award className="w-5 h-5 text-gray-400 mr-3" />
                  <div>
                    <div className="text-sm text-gray-500">Goal Weight</div>
                    <div className="font-medium">{currentUser.goalWeight} kg</div>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card className="p-6">
            <CardTitle>Achievements</CardTitle>
            
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-blue-100 flex items-center justify-center mb-2">
                  <Award className="w-6 h-6 text-blue-600" />
                </div>
                <div className="font-medium">First Workout</div>
                <div className="text-xs text-gray-500">Jan 15, 2023</div>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-green-100 flex items-center justify-center mb-2">
                  <Award className="w-6 h-6 text-green-600" />
                </div>
                <div className="font-medium">10 Workouts</div>
                <div className="text-xs text-gray-500">Feb 28, 2023</div>
              </div>
              
              <div className="bg-purple-50 p-4 rounded-lg text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <Award className="w-6 h-6 text-purple-600" />
                </div>
                <div className="font-medium">First Goal</div>
                <div className="text-xs text-gray-500">Mar 10, 2023</div>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-yellow-100 flex items-center justify-center mb-2">
                  <Award className="w-6 h-6 text-yellow-600" />
                </div>
                <div className="font-medium">5-Day Streak</div>
                <div className="text-xs text-gray-500">Apr 5, 2023</div>
              </div>
              
              <div className="bg-indigo-50 p-4 rounded-lg text-center opacity-50">
                <div className="w-12 h-12 mx-auto rounded-full bg-indigo-100 flex items-center justify-center mb-2">
                  <Award className="w-6 h-6 text-indigo-600" />
                </div>
                <div className="font-medium">25 Workouts</div>
                <div className="text-xs text-gray-500">Locked</div>
              </div>
              
              <div className="bg-red-50 p-4 rounded-lg text-center opacity-50">
                <div className="w-12 h-12 mx-auto rounded-full bg-red-100 flex items-center justify-center mb-2">
                  <Award className="w-6 h-6 text-red-600" />
                </div>
                <div className="font-medium">10K Run</div>
                <div className="text-xs text-gray-500">Locked</div>
              </div>
            </div>
          </Card>
          
          <Card className="p-6 mt-6">
            <CardTitle>Account Preferences</CardTitle>
            
            <div className="mt-4 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Email Notifications</div>
                  <div className="text-sm text-gray-500">Receive workout reminders and summaries</div>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    name="toggle" 
                    id="toggle-email" 
                    className="sr-only"
                    defaultChecked
                  />
                  <label 
                    htmlFor="toggle-email"
                    className="block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"
                  >
                    <span className="block h-6 w-6 rounded-full bg-white shadow transform transition-transform duration-200 ease-in-out translate-x-4"></span>
                  </label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Dark Mode</div>
                  <div className="text-sm text-gray-500">Switch between light and dark themes</div>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    name="toggle" 
                    id="toggle-dark" 
                    className="sr-only"
                  />
                  <label 
                    htmlFor="toggle-dark"
                    className="block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"
                  >
                    <span className="block h-6 w-6 rounded-full bg-white shadow transform transition-transform duration-200 ease-in-out"></span>
                  </label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Units</div>
                  <div className="text-sm text-gray-500">Choose between metric and imperial</div>
                </div>
                <select className="form-select rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                  <option>Metric (kg, cm)</option>
                  <option>Imperial (lb, in)</option>
                </select>
              </div>
              
              <div className="pt-4">
                <Button variant="outline" fullWidth>
                  Save Preferences
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;