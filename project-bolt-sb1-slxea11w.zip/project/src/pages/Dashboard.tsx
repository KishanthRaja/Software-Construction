import React from 'react';
import { Card } from '../components/ui/Card';
import StatCard from '../components/dashboard/StatCard';
import ProgressChart from '../components/dashboard/ProgressChart';
import ActivityCalendar from '../components/dashboard/ActivityCalendar';
import WorkoutCard from '../components/workouts/WorkoutCard';
import GoalCard from '../components/goals/GoalCard';
import { Dumbbell, Target, Flame, Award, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Link } from '../components/ui/Link';
import { dashboardStats, workouts, goals, weightEntries } from '../data/mockData';

const Dashboard: React.FC = () => {
  // Get recent and upcoming workouts
  const recentWorkouts = workouts
    .filter(w => w.completed)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 2);
    
  const upcomingWorkouts = workouts
    .filter(w => !w.completed)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 2);
    
  // Get active goals
  const activeGoals = goals
    .filter(g => !g.completed)
    .slice(0, 2);
    
  // Format weight data for chart
  const weightData = weightEntries
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(entry => ({
      date: entry.date,
      value: entry.weight,
    }));
    
  // Create activity data for calendar
  const activities = [
    ...workouts.map(workout => ({
      id: workout.id,
      date: workout.date,
      type: 'workout' as const,
      title: workout.name,
    })),
    ...goals
      .filter(goal => goal.completed)
      .map(goal => ({
        id: goal.id,
        date: goal.targetDate,
        type: 'goal' as const,
        title: `Completed: ${goal.title}`,
      })),
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Workouts This Week" 
          value={dashboardStats.workoutsThisWeek}
          icon={<Dumbbell className="w-6 h-6" />}
          change={{ value: 20, isPositive: true }}
        />
        <StatCard 
          title="Active Goals" 
          value={dashboardStats.activeGoals}
          icon={<Target className="w-6 h-6" />}
        />
        <StatCard 
          title="Calories Burned (Week)" 
          value={dashboardStats.caloriesBurnedThisWeek}
          icon={<Flame className="w-6 h-6" />}
          change={{ value: 5, isPositive: true }}
        />
        <StatCard 
          title="Current Streak" 
          value={`${dashboardStats.currentStreak} days`}
          icon={<Award className="w-6 h-6" />}
          change={{ value: 100, isPositive: true }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ProgressChart 
            title="Weight Progress"
            data={weightData}
            height={250}
            yAxisLabel="Weight (kg)"
          />
        </div>
        <div>
          <ActivityCalendar activities={activities} />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Workouts</h2>
            <Link href="/workouts" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {recentWorkouts.map(workout => (
              <WorkoutCard key={workout.id} workout={workout} />
            ))}
            {recentWorkouts.length === 0 && (
              <Card className="p-6 text-center text-gray-500">
                <p>No recent workouts found.</p>
                <Button 
                  variant="primary" 
                  className="mt-3"
                  size="sm"
                >
                  Create Workout
                </Button>
              </Card>
            )}
          </div>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Upcoming Workouts</h2>
            <Link href="/workouts" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {upcomingWorkouts.map(workout => (
              <WorkoutCard key={workout.id} workout={workout} />
            ))}
            {upcomingWorkouts.length === 0 && (
              <Card className="p-6 text-center text-gray-500">
                <p>No upcoming workouts scheduled.</p>
                <Button 
                  variant="primary" 
                  className="mt-3"
                  size="sm"
                >
                  Schedule Workout
                </Button>
              </Card>
            )}
          </div>
        </div>
      </div>
      
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Goals in Progress</h2>
          <Link href="/goals" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center">
            View All <ArrowRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {activeGoals.map(goal => (
            <GoalCard key={goal.id} goal={goal} />
          ))}
          {activeGoals.length === 0 && (
            <Card className="p-6 text-center text-gray-500 col-span-full">
              <p>No active goals found.</p>
              <Button 
                variant="primary" 
                className="mt-3"
                size="sm"
              >
                Create Goal
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;