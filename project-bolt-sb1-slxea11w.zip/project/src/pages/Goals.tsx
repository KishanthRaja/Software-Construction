import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Plus } from 'lucide-react';
import GoalCard from '../components/goals/GoalCard';
import { goals } from '../data/mockData';

const Goals: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'active' | 'completed' | 'category'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);

  // Filter goals based on selected filter
  const filteredGoals = goals.filter(goal => {
    if (filter === 'active') return !goal.completed;
    if (filter === 'completed') return goal.completed;
    if (filter === 'category' && categoryFilter) return goal.category === categoryFilter;
    return true;
  });

  // Get unique categories for filtering
  const categories = Array.from(new Set(goals.map(goal => goal.category)));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Goals</h1>
        
        <Button
          variant="primary"
          icon={<Plus className="w-4 h-4" />}
        >
          New Goal
        </Button>
      </div>
      
      <div className="flex flex-wrap gap-2">
        <Badge
          variant={filter === 'all' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => {
            setFilter('all');
            setCategoryFilter(null);
          }}
        >
          All
        </Badge>
        <Badge
          variant={filter === 'active' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => {
            setFilter('active');
            setCategoryFilter(null);
          }}
        >
          Active
        </Badge>
        <Badge
          variant={filter === 'completed' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => {
            setFilter('completed');
            setCategoryFilter(null);
          }}
        >
          Completed
        </Badge>
        
        {/* Category filters */}
        {categories.map(category => (
          <Badge
            key={category}
            variant={filter === 'category' && categoryFilter === category ? 'primary' : 'default'}
            className="cursor-pointer px-3 py-1"
            onClick={() => {
              setFilter('category');
              setCategoryFilter(category);
            }}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </Badge>
        ))}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGoals.map(goal => (
          <GoalCard key={goal.id} goal={goal} />
        ))}
        
        {filteredGoals.length === 0 && (
          <Card className="p-8 text-center col-span-full">
            <p className="text-gray-600 mb-4">No goals found matching the selected filters.</p>
            <Button
              variant="primary"
              icon={<Plus className="w-4 h-4" />}
            >
              Create Your First Goal
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Goals;