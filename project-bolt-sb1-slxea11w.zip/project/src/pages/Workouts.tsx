import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import WorkoutCard from '../components/workouts/WorkoutCard';
import { Plus, Filter, Calendar, List } from 'lucide-react';
import { workouts } from '../data/mockData';
import { isToday, isFuture, isPast } from '../utils/dateUtils';

const Workouts: React.FC = () => {
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const [filter, setFilter] = useState<'all' | 'completed' | 'upcoming' | 'today'>('all');

  // Filter workouts based on selected filter
  const filteredWorkouts = workouts.filter(workout => {
    switch (filter) {
      case 'completed':
        return workout.completed;
      case 'upcoming':
        return !workout.completed && isFuture(workout.date);
      case 'today':
        return isToday(workout.date);
      default:
        return true;
    }
  });

  // Sort workouts: upcoming first, then today, then past (most recent first)
  const sortedWorkouts = [...filteredWorkouts].sort((a, b) => {
    // If one is upcoming and the other isn't, upcoming comes first
    const aUpcoming = isFuture(a.date);
    const bUpcoming = isFuture(b.date);
    
    if (aUpcoming && !bUpcoming) return -1;
    if (!aUpcoming && bUpcoming) return 1;
    
    // If one is today and the other isn't, today comes first
    const aToday = isToday(a.date);
    const bToday = isToday(b.date);
    
    if (aToday && !bToday) return -1;
    if (!aToday && bToday) return 1;
    
    // Otherwise sort by date (newest first for past workouts, soonest first for upcoming)
    if (aUpcoming) {
      // For upcoming workouts, sort by closest date first
      return new Date(a.date).getTime() - new Date(b.date).getTime();
    } else {
      // For past workouts, sort by most recent first
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    }
  });

  // Group workouts by category for the list view
  const todayWorkouts = sortedWorkouts.filter(w => isToday(w.date));
  const upcomingWorkouts = sortedWorkouts.filter(w => isFuture(w.date) && !isToday(w.date));
  const pastWorkouts = sortedWorkouts.filter(w => isPast(w.date) && !isToday(w.date));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Workouts</h1>
        
        <div className="flex flex-wrap gap-2">
          <div className="flex rounded-md shadow-sm">
            <Button
              variant={viewMode === 'list' ? 'primary' : 'outline'}
              size="sm"
              icon={<List className="w-4 h-4" />}
              onClick={() => setViewMode('list')}
              className="rounded-r-none"
            >
              List
            </Button>
            <Button
              variant={viewMode === 'calendar' ? 'primary' : 'outline'}
              size="sm"
              icon={<Calendar className="w-4 h-4" />}
              onClick={() => setViewMode('calendar')}
              className="rounded-l-none"
            >
              Calendar
            </Button>
          </div>
          
          <Button
            variant="primary"
            size="sm"
            icon={<Plus className="w-4 h-4" />}
          >
            New Workout
          </Button>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2">
        <Badge
          variant={filter === 'all' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setFilter('all')}
        >
          All
        </Badge>
        <Badge
          variant={filter === 'today' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setFilter('today')}
        >
          Today
        </Badge>
        <Badge
          variant={filter === 'upcoming' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setFilter('upcoming')}
        >
          Upcoming
        </Badge>
        <Badge
          variant={filter === 'completed' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setFilter('completed')}
        >
          Completed
        </Badge>
        <Button
          variant="outline"
          size="sm"
          icon={<Filter className="w-4 h-4" />}
        >
          More Filters
        </Button>
      </div>
      
      {viewMode === 'list' ? (
        <div className="space-y-8">
          {/* Today's workouts */}
          {todayWorkouts.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Today</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {todayWorkouts.map(workout => (
                  <WorkoutCard key={workout.id} workout={workout} />
                ))}
              </div>
            </div>
          )}
          
          {/* Upcoming workouts */}
          {upcomingWorkouts.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Upcoming</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {upcomingWorkouts.map(workout => (
                  <WorkoutCard key={workout.id} workout={workout} />
                ))}
              </div>
            </div>
          )}
          
          {/* Past workouts */}
          {pastWorkouts.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Past</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {pastWorkouts.map(workout => (
                  <WorkoutCard key={workout.id} workout={workout} />
                ))}
              </div>
            </div>
          )}
          
          {/* No workouts message */}
          {sortedWorkouts.length === 0 && (
            <Card className="p-8 text-center">
              <p className="text-gray-600 mb-4">No workouts found matching the selected filters.</p>
              <Button
                variant="primary"
                icon={<Plus className="w-4 h-4" />}
              >
                Create Your First Workout
              </Button>
            </Card>
          )}
        </div>
      ) : (
        // Calendar view placeholder - in a real app, this would be a full calendar component
        <Card className="p-6 text-center bg-white rounded-lg shadow-sm">
          <p className="text-gray-600 mb-4">Calendar view is not implemented in this demo.</p>
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-sm font-medium p-2">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: 35 }).map((_, i) => (
              <div 
                key={i} 
                className="border border-gray-200 aspect-square flex items-center justify-center text-sm hover:bg-gray-50"
              >
                {i + 1}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default Workouts;