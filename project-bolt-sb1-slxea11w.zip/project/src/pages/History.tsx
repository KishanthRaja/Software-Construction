import React, { useState } from 'react';
import { Card, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Filter, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { workouts, weightEntries } from '../data/mockData';
import ProgressChart from '../components/dashboard/ProgressChart';
import { formatReadable, formatDuration } from '../utils/dateUtils';

const History: React.FC = () => {
  const [viewType, setViewType] = useState<'workouts' | 'weight' | 'all'>('all');
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());
  
  const monthName = selectedMonth.toLocaleString('default', { month: 'long' });
  const year = selectedMonth.getFullYear();
  
  // Navigate to previous/next month
  const previousMonth = () => {
    setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() - 1, 1));
  };
  
  const nextMonth = () => {
    setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 1));
  };
  
  // Filter workouts for the selected month
  const filteredWorkouts = workouts.filter(workout => {
    const workoutDate = new Date(workout.date);
    return workoutDate.getMonth() === selectedMonth.getMonth() && 
           workoutDate.getFullYear() === selectedMonth.getFullYear();
  });
  
  // Format weight data for chart
  const weightData = weightEntries
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(entry => ({
      date: entry.date,
      value: entry.weight,
    }));
  
  // Calculate workout stats
  const totalWorkouts = filteredWorkouts.length;
  const totalDuration = filteredWorkouts.reduce((sum, workout) => sum + workout.duration, 0);
  const totalCalories = filteredWorkouts.reduce((sum, workout) => sum + (workout.caloriesBurned || 0), 0);
  
  // Get most common exercise
  const exerciseCounts: Record<string, number> = {};
  filteredWorkouts.forEach(workout => {
    workout.sets.forEach(set => {
      if (!exerciseCounts[set.exerciseId]) {
        exerciseCounts[set.exerciseId] = 0;
      }
      exerciseCounts[set.exerciseId]++;
    });
  });
  
  const mostCommonExerciseId = Object.entries(exerciseCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([id]) => id)[0];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">History & Stats</h1>
        
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center space-x-1">
            <Button
              variant="outline"
              size="sm"
              icon={<ChevronLeft className="w-4 h-4" />}
              onClick={previousMonth}
              className="px-2"
            />
            <span className="px-2 font-medium">
              {monthName} {year}
            </span>
            <Button
              variant="outline"
              size="sm"
              icon={<ChevronRight className="w-4 h-4" />}
              onClick={nextMonth}
              className="px-2"
            />
          </div>
          
          <Button
            variant="outline"
            size="sm"
            icon={<Filter className="w-4 h-4" />}
          >
            Export Data
          </Button>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2">
        <Badge
          variant={viewType === 'all' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setViewType('all')}
        >
          All Stats
        </Badge>
        <Badge
          variant={viewType === 'workouts' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setViewType('workouts')}
        >
          Workouts
        </Badge>
        <Badge
          variant={viewType === 'weight' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setViewType('weight')}
        >
          Weight Tracking
        </Badge>
      </div>
      
      {/* Monthly stats summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-sm text-gray-500">Workouts</div>
          <div className="text-2xl font-bold text-blue-600">{totalWorkouts}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-500">Total Time</div>
          <div className="text-2xl font-bold text-blue-600">{formatDuration(totalDuration)}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-500">Calories Burned</div>
          <div className="text-2xl font-bold text-blue-600">{totalCalories}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-500">Favorite Exercise</div>
          <div className="text-2xl font-bold text-blue-600">
            {mostCommonExerciseId ? 'Bench Press' : 'N/A'}
          </div>
        </Card>
      </div>
      
      {/* Weight progress chart - show if viewType is 'all' or 'weight' */}
      {(viewType === 'all' || viewType === 'weight') && (
        <div className="mt-6">
          <ProgressChart 
            title="Weight History"
            data={weightData}
            height={300}
            yAxisLabel="Weight (kg)"
            xAxisLabel="Date"
          />
        </div>
      )}
      
      {/* Workout history - show if viewType is 'all' or 'workouts' */}
      {(viewType === 'all' || viewType === 'workouts') && (
        <div className="mt-6">
          <Card>
            <div className="p-6">
              <CardTitle>Workout History</CardTitle>
              
              {filteredWorkouts.length > 0 ? (
                <div className="mt-4 overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead>
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Workout
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Duration
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Calories
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredWorkouts
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map(workout => (
                          <tr key={workout.id} className="hover:bg-gray-50 cursor-pointer">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {formatReadable(workout.date)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {workout.name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {formatDuration(workout.duration)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {workout.caloriesBurned || 'N/A'}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No workouts found for {monthName} {year}
                </div>
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default History;