import React, { useState } from 'react';
import { Card, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Plus, PieChart } from 'lucide-react';
import NutritionCard from '../components/nutrition/NutritionCard';
import { nutritionEntries } from '../data/mockData';
import { formatReadable } from '../utils/dateUtils';

const Nutrition: React.FC = () => {
  const [dateFilter, setDateFilter] = useState<string>('today');

  // Group nutrition entries by date
  const entriesByDate = nutritionEntries.reduce((acc, entry) => {
    if (!acc[entry.date]) {
      acc[entry.date] = [];
    }
    acc[entry.date].push(entry);
    return acc;
  }, {} as Record<string, typeof nutritionEntries>);

  // Sort dates in descending order (newest first)
  const sortedDates = Object.keys(entriesByDate).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  );

  // Calculate daily totals
  const dailyTotals = Object.entries(entriesByDate).map(([date, entries]) => {
    const totalCalories = entries.reduce((sum, entry) => sum + entry.calories, 0);
    const totalProtein = entries.reduce((sum, entry) => sum + entry.protein, 0);
    const totalCarbs = entries.reduce((sum, entry) => sum + entry.carbs, 0);
    const totalFat = entries.reduce((sum, entry) => sum + entry.fat, 0);
    
    return {
      date,
      calories: totalCalories,
      protein: totalProtein,
      carbs: totalCarbs,
      fat: totalFat,
    };
  });

  // Filter entries by selected date
  const selectedDateEntries = dateFilter === 'all' 
    ? nutritionEntries 
    : (entriesByDate[sortedDates[0]] || []);

  // Group by meal type for the selected date
  const entriesByMealType = selectedDateEntries.reduce((acc, entry) => {
    if (!acc[entry.mealType]) {
      acc[entry.mealType] = [];
    }
    acc[entry.mealType].push(entry);
    return acc;
  }, {} as Record<string, typeof nutritionEntries>);

  // Calculate macronutrient percentages for pie chart
  const selectedDateTotals = dailyTotals.find(t => t.date === (dateFilter === 'all' ? sortedDates[0] : sortedDates[0]));
  const totalMacros = selectedDateTotals ? selectedDateTotals.protein + selectedDateTotals.carbs + selectedDateTotals.fat : 0;
  
  const macroPercentages = {
    protein: totalMacros ? Math.round((selectedDateTotals?.protein || 0) / totalMacros * 100) : 0,
    carbs: totalMacros ? Math.round((selectedDateTotals?.carbs || 0) / totalMacros * 100) : 0,
    fat: totalMacros ? Math.round((selectedDateTotals?.fat || 0) / totalMacros * 100) : 0,
  };

  // Create data for macronutrient pie chart
  const createPieChart = () => {
    const radius = 50;
    const centerX = 100;
    const centerY = 100;
    
    // Calculate angles for each macronutrient
    let startAngle = 0;
    const segments = [
      { name: 'protein', percentage: macroPercentages.protein, color: '#3B82F6' },
      { name: 'carbs', percentage: macroPercentages.carbs, color: '#10B981' },
      { name: 'fat', percentage: macroPercentages.fat, color: '#F59E0B' },
    ];
    
    return (
      <svg width="200" height="200" viewBox="0 0 200 200">
        {segments.map((segment, index) => {
          // Skip if percentage is 0
          if (segment.percentage === 0) return null;
          
          // Convert percentage to radians
          const angle = (segment.percentage / 100) * Math.PI * 2;
          const endAngle = startAngle + angle;
          
          // Calculate points
          const x1 = centerX + radius * Math.cos(startAngle);
          const y1 = centerY + radius * Math.sin(startAngle);
          const x2 = centerX + radius * Math.cos(endAngle);
          const y2 = centerY + radius * Math.sin(endAngle);
          
          // Create path
          const largeArc = angle > Math.PI ? 1 : 0;
          const path = `
            M ${centerX} ${centerY}
            L ${x1} ${y1}
            A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}
            Z
          `;
          
          // Update start angle for next segment
          startAngle = endAngle;
          
          return (
            <path
              key={index}
              d={path}
              fill={segment.color}
            />
          );
        })}
        
        {/* Add labels */}
        <text x="100" y="170" fontSize="12" textAnchor="middle" fill="#4B5563">
          Protein: {macroPercentages.protein}%
        </text>
        <text x="100" y="185" fontSize="12" textAnchor="middle" fill="#4B5563">
          Carbs: {macroPercentages.carbs}%
        </text>
        <text x="100" y="200" fontSize="12" textAnchor="middle" fill="#4B5563">
          Fat: {macroPercentages.fat}%
        </text>
      </svg>
    );
  };

  const mealTypes = ['breakfast', 'lunch', 'dinner', 'snack'] as const;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Nutrition</h1>
        
        <Button
          variant="primary"
          icon={<Plus className="w-4 h-4" />}
        >
          Add Meal
        </Button>
      </div>
      
      <div className="flex flex-wrap gap-2">
        {sortedDates.slice(0, 5).map((date, index) => (
          <Badge
            key={date}
            variant={date === sortedDates[0] && dateFilter !== 'all' ? 'primary' : 'default'}
            className="cursor-pointer px-3 py-1"
            onClick={() => setDateFilter(date)}
          >
            {index === 0 ? 'Today' : formatReadable(date)}
          </Badge>
        ))}
        <Badge
          variant={dateFilter === 'all' ? 'primary' : 'default'}
          className="cursor-pointer px-3 py-1"
          onClick={() => setDateFilter('all')}
        >
          All
        </Badge>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <div className="p-6">
              <CardTitle>Nutritional Summary</CardTitle>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-500">Calories</div>
                  <div className="text-2xl font-bold text-blue-600">
                    {selectedDateTotals?.calories || 0}
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-500">Protein</div>
                  <div className="text-2xl font-bold text-blue-600">
                    {selectedDateTotals?.protein || 0}g
                  </div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-500">Carbs</div>
                  <div className="text-2xl font-bold text-green-600">
                    {selectedDateTotals?.carbs || 0}g
                  </div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-500">Fat</div>
                  <div className="text-2xl font-bold text-yellow-600">
                    {selectedDateTotals?.fat || 0}g
                  </div>
                </div>
              </div>
            </div>
          </Card>
          
          <div className="mt-6">
            {selectedDateEntries.length > 0 ? (
              <div className="space-y-6">
                {mealTypes.map(mealType => {
                  const mealEntries = entriesByMealType[mealType] || [];
                  if (mealEntries.length === 0) return null;
                  
                  return (
                    <div key={mealType}>
                      <h2 className="text-lg font-semibold text-gray-900 mb-4 capitalize">
                        {mealType}
                      </h2>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {mealEntries.map(entry => (
                          <NutritionCard key={entry.id} entry={entry} />
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <p className="text-gray-600 mb-4">No nutrition entries found for the selected date.</p>
                <Button
                  variant="primary"
                  icon={<Plus className="w-4 h-4" />}
                >
                  Add Your First Meal
                </Button>
              </Card>
            )}
          </div>
        </div>
        
        <div>
          <Card>
            <div className="p-6">
              <CardTitle>Macronutrient Balance</CardTitle>
              
              <div className="flex justify-center mt-4">
                {totalMacros > 0 ? (
                  createPieChart()
                ) : (
                  <div className="text-center py-10">
                    <PieChart className="w-12 h-12 mx-auto text-gray-300" />
                    <p className="mt-2 text-gray-500">No data available</p>
                  </div>
                )}
              </div>
            </div>
          </Card>
          
          <Card className="mt-6">
            <div className="p-6">
              <CardTitle>Daily Targets</CardTitle>
              
              <div className="space-y-4 mt-4">
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Calories</span>
                    <span className="font-medium">{selectedDateTotals?.calories || 0} / 2000</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min(((selectedDateTotals?.calories || 0) / 2000) * 100, 100)}%` 
                      }}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Protein</span>
                    <span className="font-medium">{selectedDateTotals?.protein || 0}g / 150g</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min(((selectedDateTotals?.protein || 0) / 150) * 100, 100)}%` 
                      }}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Carbs</span>
                    <span className="font-medium">{selectedDateTotals?.carbs || 0}g / 200g</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min(((selectedDateTotals?.carbs || 0) / 200) * 100, 100)}%` 
                      }}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm">
                    <span>Fat</span>
                    <span className="font-medium">{selectedDateTotals?.fat || 0}g / 65g</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className="bg-yellow-500 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min(((selectedDateTotals?.fat || 0) / 65) * 100, 100)}%` 
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Nutrition;