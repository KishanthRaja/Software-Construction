import { User, Exercise, Workout, Goal, NutritionEntry, WeightEntry, DashboardStats, WorkoutSet } from '../types';
import { subDays, format, addDays } from '../utils/dateUtils';

// Current user
export const currentUser: User = {
  id: 'user1',
  name: 'Alex Johnson',
  email: 'alex@example.com',
  height: 175,
  weight: 78,
  goalWeight: 75,
  dateOfBirth: '1990-05-15',
  joinedDate: '2023-01-10',
};

// Exercise library
export const exercises: Exercise[] = [
  {
    id: 'ex1',
    name: 'Bench Press',
    category: 'strength',
    muscleGroups: ['chest', 'triceps', 'shoulders'],
    defaultSets: 4,
    defaultReps: 10,
    defaultWeight: 60,
  },
  {
    id: 'ex2',
    name: 'Squats',
    category: 'strength',
    muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves'],
    defaultSets: 4,
    defaultReps: 10,
    defaultWeight: 80,
  },
  {
    id: 'ex3',
    name: 'Running',
    category: 'cardio',
    muscleGroups: ['heart', 'legs'],
    defaultDuration: 1800, // 30 minutes
    defaultDistance: 5000, // 5km
  },
  {
    id: 'ex4',
    name: 'Deadlift',
    category: 'strength',
    muscleGroups: ['back', 'hamstrings', 'glutes', 'forearms'],
    defaultSets: 3,
    defaultReps: 8,
    defaultWeight: 100,
  },
  {
    id: 'ex5',
    name: 'Shoulder Press',
    category: 'strength',
    muscleGroups: ['shoulders', 'triceps'],
    defaultSets: 3,
    defaultReps: 12,
    defaultWeight: 40,
  },
  {
    id: 'ex6',
    name: 'Yoga',
    category: 'flexibility',
    muscleGroups: ['full body'],
    defaultDuration: 3600, // 60 minutes
  },
];

// Generate dates for the last 30 days
const today = new Date();
const getDateString = (daysAgo: number) => format(subDays(today, daysAgo));

// Create workout sets
const createWorkoutSets = (exerciseId: string, completed: boolean): WorkoutSet[] => {
  const sets: WorkoutSet[] = [];
  const exercise = exercises.find(ex => ex.id === exerciseId);
  
  if (!exercise) return sets;
  
  const count = exercise.defaultSets || 3;
  
  for (let i = 0; i < count; i++) {
    sets.push({
      id: `set-${exerciseId}-${i}`,
      exerciseId,
      reps: exercise.defaultReps,
      weight: exercise.defaultWeight,
      duration: exercise.defaultDuration,
      distance: exercise.defaultDistance,
      completed,
    });
  }
  
  return sets;
};

// Workouts
export const workouts: Workout[] = [
  {
    id: 'w1',
    userId: 'user1',
    name: 'Chest Day',
    date: getDateString(6),
    duration: 3600, // 60 minutes
    caloriesBurned: 450,
    notes: 'Felt strong today',
    sets: [...createWorkoutSets('ex1', true), ...createWorkoutSets('ex5', true)],
    completed: true,
  },
  {
    id: 'w2',
    userId: 'user1',
    name: 'Leg Day',
    date: getDateString(4),
    duration: 4200, // 70 minutes
    caloriesBurned: 520,
    notes: 'Increased weight on squats',
    sets: [...createWorkoutSets('ex2', true), ...createWorkoutSets('ex4', true)],
    completed: true,
  },
  {
    id: 'w3',
    userId: 'user1',
    name: 'Cardio Session',
    date: getDateString(2),
    duration: 1800, // 30 minutes
    caloriesBurned: 320,
    sets: createWorkoutSets('ex3', true),
    completed: true,
  },
  {
    id: 'w4',
    userId: 'user1',
    name: 'Full Body Workout',
    date: getDateString(0),
    duration: 5400, // 90 minutes
    caloriesBurned: 680,
    notes: 'Great session overall',
    sets: [
      ...createWorkoutSets('ex1', true),
      ...createWorkoutSets('ex2', true),
      ...createWorkoutSets('ex5', true),
    ],
    completed: true,
  },
  {
    id: 'w5',
    userId: 'user1',
    name: 'Back & Shoulders',
    date: format(addDays(today, 1)),
    duration: 3600, // 60 minutes (planned)
    sets: [...createWorkoutSets('ex4', false), ...createWorkoutSets('ex5', false)],
    completed: false,
  },
];

// Goals
export const goals: Goal[] = [
  {
    id: 'g1',
    userId: 'user1',
    title: 'Lose Weight',
    description: 'Get to my target weight before summer',
    targetDate: format(addDays(today, 60)),
    category: 'weight',
    targetValue: 75,
    currentValue: 78,
    unit: 'kg',
    completed: false,
  },
  {
    id: 'g2',
    userId: 'user1',
    title: 'Bench Press Goal',
    description: 'Increase bench press max weight',
    targetDate: format(addDays(today, 90)),
    category: 'workout',
    targetValue: 100,
    currentValue: 85,
    unit: 'kg',
    completed: false,
  },
  {
    id: 'g3',
    userId: 'user1',
    title: 'Run 10K',
    description: 'Complete a 10K run under 50 minutes',
    targetDate: format(addDays(today, 45)),
    category: 'workout',
    targetValue: 50,
    currentValue: 55,
    unit: 'minutes',
    completed: false,
  },
  {
    id: 'g4',
    userId: 'user1',
    title: 'Daily Protein Goal',
    description: 'Consume at least 150g of protein daily',
    targetDate: 'ongoing',
    category: 'nutrition',
    targetValue: 150,
    currentValue: 135,
    unit: 'g',
    completed: false,
  },
];

// Nutrition entries
export const nutritionEntries: NutritionEntry[] = [
  {
    id: 'n1',
    userId: 'user1',
    date: getDateString(0),
    mealType: 'breakfast',
    foodName: 'Protein Oatmeal',
    calories: 380,
    protein: 30,
    carbs: 45,
    fat: 10,
  },
  {
    id: 'n2',
    userId: 'user1',
    date: getDateString(0),
    mealType: 'lunch',
    foodName: 'Chicken Salad',
    calories: 450,
    protein: 40,
    carbs: 25,
    fat: 15,
  },
  {
    id: 'n3',
    userId: 'user1',
    date: getDateString(0),
    mealType: 'dinner',
    foodName: 'Salmon with Veggies',
    calories: 520,
    protein: 35,
    carbs: 30,
    fat: 25,
  },
  {
    id: 'n4',
    userId: 'user1',
    date: getDateString(0),
    mealType: 'snack',
    foodName: 'Protein Shake',
    calories: 180,
    protein: 30,
    carbs: 5,
    fat: 3,
  },
];

// Weight entries for the past 30 days
export const weightEntries: WeightEntry[] = Array.from({ length: 30 }, (_, i) => {
  // Create a slight downward trend with some randomness
  const baseWeight = 80 - (i * 0.08);
  const randomVariation = (Math.random() * 0.6) - 0.3; // Between -0.3 and 0.3
  
  return {
    id: `weight-${i}`,
    userId: 'user1',
    date: getDateString(29 - i),
    weight: Math.round((baseWeight + randomVariation) * 10) / 10,
  };
});

// Dashboard stats
export const dashboardStats: DashboardStats = {
  workoutsThisWeek: 3,
  totalWorkouts: 24,
  activeGoals: 4,
  completedGoals: 2,
  currentStreak: 4,
  caloriesBurnedThisWeek: 1450,
};